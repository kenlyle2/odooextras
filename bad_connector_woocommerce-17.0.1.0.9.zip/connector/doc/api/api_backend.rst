######
Models
######

.. _api-backend-model:

*************
Backend Model
*************


.. autoclass:: connector.models.backend_model.ConnectorBackend
   :members:
   :undoc-members:
   :show-inheritance:

.. _api-binding-model:

*************
Binding Model
*************

.. autoclass:: connector.models.backend_model.ExternalBinding
   :show-inheritance:
