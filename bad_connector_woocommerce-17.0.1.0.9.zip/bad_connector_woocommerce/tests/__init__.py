"""Tests Files"""
from . import test_woo_backend
from . import test_import_partner
from . import test_import_product_category
from . import test_import_product_attribute
from . import test_import_product_tag
from . import test_import_product
from . import test_import_sale_order
from . import test_import_woo_tax
from . import test_import_country_and_state
from . import test_woo_tax_setting
from . import test_import_product_tag1
from . import test_import_payment_gateway
from . import test_export_refund
from . import test_auto_process_return
from . import test_import_refund
