External Notifications v1.0.0
==============================

* Receives notifications about new customers, orders from WooCommerce website


Depends
=======
[website] addon Odoo
[website_sale] addon Odoo


Tech
====
* [jQuery] - Search AutoComplete
* [Python] - Controllers
* [XML] - Odoo website templates


Installation
============
- www.odoo.com/documentation/17.0/setup/install.html
- Install our custom addon


Author
------

Developer: Pektsekye hottons.com


Maintainer
----------

For support and more information contact me by email pektsekye@gmail.com
