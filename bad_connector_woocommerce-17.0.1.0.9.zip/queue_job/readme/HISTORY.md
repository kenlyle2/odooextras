## Next

- \[ADD\] Run jobrunner as a worker process instead of a thread in the
  main process (when running with --workers \> 0)
- \[REF\] `@job` and `@related_action` deprecated, any method can be
  delayed, and configured using `queue.job.function` records
- \[MIGRATION\] from 13.0 branched at rev. e24ff4b
