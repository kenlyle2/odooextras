odoo.define('enotif.general', [], function (require) {
'use strict';

  var owl = require('@odoo/owl');
  var coreRegistry = require('@web/core/registry');      
  var hooks = require('@web/core/utils/hooks');        
 
 
  class MenuAction extends owl.Component {
    
    static template = "enotif_template_progress";
  //  static props = {};
    
        
    setup() {
      
      this.rpc = hooks.useService('rpc');

      owl.onWillStart(async () => {
        var self = this;
        await this.rpc('/enotif/init', {}).then(function (data) {
          $.extend(self, data);
        });

        this.data = {
          items : this.items,
          process_notifications : this.process_notifications
        }
      });
      
      owl.onMounted(() => {          
        this.resultDiv = $('#enotif_get_notifications_result');
        $('button.delete-notifications').click($.proxy(this.deleteNotifications, this));
        $('button.toggle-state').click($.proxy(this.toggleState, this));
        $('#enotif_get_new_notifications').click($.proxy(this.getNewNotifications, this));                           
      });        

    }
    
    
    deleteNotifications(e) {
   
      var confirmed = confirm("Are you sure you would like to delete these notifications?");    
      if (!confirmed)
        return

      var resultDiv = $('#enotif_delete_notifications_result');
        
      var button = $(e.target);
      var type = button.data('type');      
      var typeId = parseInt(button.data('type_id'));    
      var itemIds = this.itemIdsByTypeId[typeId];
      
      var params = {'type_id': typeId, 'item_ids': itemIds};     

      this.rpc('/enotif/delete_notifications', params).then(function (data) {
      
         if (data){         
           if (!data.error){              
              resultDiv.html('The notifications of type "' + type + '" were deleted.');
              button.closest('tr').hide();                                         
           } else {           
              resultDiv.html('There was some error. Check server logs.');                
           }
         }
      }).catch(function(){ 
         resultDiv.html('<span class="error-message">ERROR: check if the Odoo server is running. Check server logs.</span>');
      });
          
    }
    
    
    toggleState() {

      var resultDiv = $('#enotif_toggle_state_result');
               
      this.rpc('/enotif/toggle_state', {}).then(function (data) {
      
         if (data){         
           if (!data.error){
              if (data.active){
                $('.state-stopped').hide();
                $('.state-active').show();
                resultDiv.html('The processing is active now.');
                $('#enotif_progress').show();
              } else {              
                $('.state-active').hide();
                $('.state-stopped').show();
                resultDiv.html('The processing is stopped.');
                $('#enotif_progress').hide();
              }                                         
           } else {           
              resultDiv.html('There was some error. Check server logs.');                
           }
         }
      }).catch(function(){ 
         resultDiv.html('<span class="error-message">ERROR: check if the Odoo server is running. Check server logs.</span>');
      });
          
    }
    
           
    getNewNotifications() {
      
      var resultDiv = $('#enotif_get_new_notifications_result');   
         
      this.rpc('/enotif/get_new_notifications', {}).then(function (data) {
      
         if (data){      
            
           if (!data.error){
           
              if (data.notifications_number > 0){
               resultDiv.html('There are new notifications. Reload this page to see the updated information.');
              } else {              
               resultDiv.html('There are no new notifications.');
              }     
                                                  
           } else {       
            
              var message = 'Server error message:<br><textarea style="resize:both;height:100px">' + data.error_text + '</textarea><br/>';
              
              message += 'Check connection in the "WooCommerce Keys" section. And check if the Notify Odoo plugin is enabled on the WooCommerce website.';
              
              resultDiv.html(message);                             
           }
         }
      }).catch(function(){ 
         resultDiv.html('<span class="error-message">ERROR: check if the Odoo server is running. Check server logs.</span>');
      });
          
    } 
     
  } 

  coreRegistry.registry.category("actions").add("enotif-action", MenuAction);
  
  return MenuAction;
});

