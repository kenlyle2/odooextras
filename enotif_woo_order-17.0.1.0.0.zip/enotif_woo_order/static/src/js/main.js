odoo.define('enotif_woo_order.order', [], function (require) {
'use strict';

  var owl = require('@odoo/owl');
  var coreRegistry = require('@web/core/registry');      
  var hooks = require('@web/core/utils/hooks');
     

  class MenuAction extends owl.Component {
  
    static template = "enotif_woo_template_order";
  //  static props = {};
     
        
    setup() {   
    
      this.rpc = hooks.useService('rpc');    
               
      owl.onMounted(() => {          
        this.resultDiv = $('#enotif_woo_order_result');
        $('#enotif_woo_order_import_orders').click($.proxy(this.importOrders, this));           
      });               
    }  
      
        
    importOrders() {
      
      var self = this;   
         
      this.rpc('/enotif_woo_order/import_orders', {}).then(function (data) {
      
         if (data){
         
           if (!data.error){
           
              var message = '';
              
              if (data.number_of_orders > 0){
                message += 'Number of orders to import <b>' + data.number_of_orders + '</b></br></br>';
                
                message += 'The importing process will start in three minutes.</br></br>';
                
                message += 'You can view the process status in the "Progress" section.</br></br>';
                                                             
              } else {
                message += 'There are no new orders on the remote website. Or orders with the same email already exist.</br></br>';                                             
              }
              
              self.resultDiv.html(message);
              
           } else {
           
              var message = 'Server error message:<br><textarea style="resize:both">' + data.error_text + '</textarea><br/>';
              
              message += 'Check connection in the "WooCommerce Keys" section';
              
              self.resultDiv.html(message);                
           }
         }
      }).catch(function(){ 
         self.resultDiv.html('<span class="error-message">ERROR: check if the Odoo server is running. Check server logs.</span>');
      });                          
    }  
      
  };
      
  coreRegistry.registry.category("actions").add("enotif-woo-order-action", MenuAction);
  
  return MenuAction;
});

