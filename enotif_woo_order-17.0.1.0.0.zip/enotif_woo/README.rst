Enotif WooCommerce v1.0.0
==============================

* Connects the "External Notifications" module to WooCommerce website


Depends
=======
[enotif] addon External Notifications


Tech
====
* [jQuery] - Search AutoComplete
* [Python] - Controllers
* [XML] - Odoo website templates


Installation
============
- www.odoo.com/documentation/17.0/setup/install.html
- Install our custom addon


Author
------

Developer: Pektsekye hottons.com


Maintainer
----------

For support and more information contact me by email pektsekye@gmail.com